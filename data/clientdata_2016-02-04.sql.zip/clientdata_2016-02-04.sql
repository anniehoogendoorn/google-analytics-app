# ************************************************************
# Sequel Pro SQL dump
# Version 4500
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: sq1clientdata.czbzihzhfgaj.us-east-1.rds.amazonaws.com (MySQL 5.6.23-log)
# Database: clientdata
# Generation Time: 2016-02-04 16:21:46 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table adwords_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `adwords_data`;

CREATE TABLE `adwords_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `services_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_id` (`services_id`),
  CONSTRAINT `adwords_data_ibfk_1` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site1
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site1`;

CREATE TABLE `analytics_site1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site1_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site2
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site2`;

CREATE TABLE `analytics_site2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site2_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site3
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site3`;

CREATE TABLE `analytics_site3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site3_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site4
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site4`;

CREATE TABLE `analytics_site4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site4_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site5
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site5`;

CREATE TABLE `analytics_site5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site5_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site6
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site6`;

CREATE TABLE `analytics_site6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site6_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site7
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site7`;

CREATE TABLE `analytics_site7` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site7_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table analytics_site8
# ------------------------------------------------------------

DROP TABLE IF EXISTS `analytics_site8`;

CREATE TABLE `analytics_site8` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sites_id` int(11) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `medium` varchar(255) DEFAULT NULL,
  `channel_grouping` varchar(255) DEFAULT NULL,
  `device_category` varchar(255) DEFAULT NULL,
  `landing_page_path` varchar(255) DEFAULT NULL,
  `sessions` varchar(255) DEFAULT NULL,
  `transactions` varchar(255) DEFAULT NULL,
  `transaction_revenue` varchar(255) DEFAULT NULL,
  `page_views` varchar(255) DEFAULT NULL,
  `bounces` varchar(255) DEFAULT NULL,
  `session_duration` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `total_events` varchar(255) DEFAULT NULL,
  `unique_events` varchar(255) DEFAULT NULL,
  `users` varchar(255) DEFAULT NULL,
  `entrances` varchar(255) DEFAULT NULL,
  `exits` varchar(255) DEFAULT NULL COMMENT ' ',
  PRIMARY KEY (`id`),
  KEY `sites_id` (`sites_id`),
  CONSTRAINT `analytics_site8_ibfk_1` FOREIGN KEY (`sites_id`) REFERENCES `sites` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table facebook_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `facebook_data`;

CREATE TABLE `facebook_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `services_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_id` (`services_id`),
  CONSTRAINT `facebook_data_ibfk_1` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table services
# ------------------------------------------------------------

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sites`;

CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `services_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `analytics_profile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_id` (`services_id`),
  CONSTRAINT `sites_ibfk_1` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table twitter_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `twitter_data`;

CREATE TABLE `twitter_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `services_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_id` (`services_id`),
  CONSTRAINT `twitter_data_ibfk_1` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
